/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import javax.swing.JOptionPane;
import model.pelanggan;
import view.viewpelanggan;

/**
 *
 * @author pc
 */
public class pelanggancontroller {
    
    private pelanggan model;

    public void setModel(pelanggan model) {
        this.model = model;
    }
    
    
    
    public void resetForm(viewpelanggan view){
        
        String nama = view.getTxtNama().getText();
        String email = view.getTxtEmail().getText();
        String Nohp = view.getTxtNohp().getText();
        
        if (nama.equals("") && email.equals("") && Nohp.equals("")) {
    } else {
            model.resetForm();
        }
    }
    public void simpanForm(viewpelanggan view){
        
        String nama = view.getTxtNama().getText();
        String email = view.getTxtEmail().getText();
        String nohp = view.getTxtNohp().getText();
        
        if(nama.trim().equals("")){
            JOptionPane.showMessageDialog(view, "Nama masih kosong");
            
        } else if (email.trim().equals("")){
            JOptionPane.showMessageDialog(view, "Email masih kosong");
        } else if (nohp.trim().equals("")){
            JOptionPane.showMessageDialog(view, "No HP masih kosong");
        } else {
            model.simpanForm();
        }
    }
    
}
