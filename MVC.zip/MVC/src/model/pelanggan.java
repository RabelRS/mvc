/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import event.pelangganlistener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author pc
 */
public class pelanggan {
    
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/db_barbershop";
    static final String USER = "root";
    static final String PASS = ""; 
    public Connection koneksi;
    public Statement statement;
    int jmlData;
    public pelanggan() {
        try{
            Class.forName(JDBC_DRIVER);
            koneksi = (java.sql.Connection) DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Koneksi Berhasil ke MySQL");
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
            System.out.println("Koneksi Gagal");
        }   
    }  
    
    
    private String nama;
    private String email;
    private String nohp;
    
    private pelangganlistener pelangganlistener;

    public pelangganlistener getPelangganlistener() {
        return pelangganlistener;
    }

    public void setPelangganlistener(pelangganlistener pelangganlistener) {
        this.pelangganlistener = pelangganlistener;
    }
    
    

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
        fireOnChange();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
        fireOnChange();
    }

    public String getNohp() {
        return nohp;
    }

    public void setNohp(String nohp) {
        this.nohp = nohp;
        fireOnChange();
    }
    
    
    protected void fireOnChange(){
        if (pelangganlistener!=null){
            pelangganlistener.onChange(this);
        }
        
    }
    
    public void resetForm() {
        setNama("");
        setEmail("");
        setNohp("");
        
    }
    
    public void simpanForm(){
        JOptionPane.showMessageDialog(null,"Berhasil Disimpan");
        resetForm();
    }
    
}
